<?php
// Menerima status callback dari Twilio
$callSid = $_POST['CallSid'] ?? 'UNKNOWN';
$callStatus = $_POST['CallStatus'] ?? 'UNKNOWN';

// Simpan status panggilan ke log atau database
file_put_contents('call_status.log', "Call SID: $callSid - Status: $callStatus\n", FILE_APPEND);

// Kirim respons ke Twilio
http_response_code(200);
echo json_encode(["status" => "received", "call_sid" => $callSid, "call_status" => $callStatus]);
?>
