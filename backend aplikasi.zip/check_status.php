<?php
require __DIR__ . '/vendor/autoload.php';
use Twilio\Rest\Client;
require 'config.php';

if (!isset($_GET['call_sid'])) {
    echo json_encode(["status" => "error", "message" => "Call SID tidak boleh kosong"]);
    exit;
}

$callSid = $_GET['call_sid'];

try {
    $call = $twilio->calls($callSid)->fetch();
    echo json_encode(["status" => "ok", "call_status" => $call->status], JSON_PRETTY_PRINT);
} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>
