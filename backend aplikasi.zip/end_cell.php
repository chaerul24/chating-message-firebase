<?php
require 'vendor/autoload.php';
require 'config.php';
use Twilio\Rest\Client;

if (isset($_GET['call_sid'])) {
    $callSid = $_GET['call_sid'];

    $call = $twilio->calls($callSid)->update([
        "status" => "completed"
    ]);

    echo json_encode(["status" => "ok", "message" => "Call ended"]);
} else {
    echo json_encode(["status" => "error", "message" => "Call SID required"]);
}
?>
