<?php
header('Content-Type: application/json');
require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/brevo/brevo.php';
require __DIR__ . '/brevo/config.php';
require __DIR__ . '/db/config.php';

$db = new Database();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if(isset($_GET['email']) && isset($_GET['otp'])) {
        $email = $_GET['email'];
        $otp = $_GET['otp'];
        echo $result = $db->verifyOTP($email, $otp);
        
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Email and OTP is required'], JSON_PRETTY_PRINT);
    }
}
