<?php
class Database {
    // private $user = "diutqwgy_iot";
    // private $pass = "9+*En46TNWW#";
    // private $server = "localhost";
    // private $dbname = "diutqwgy_iot";


    private $user = "root";
    private $pass = "root";
    private $server = "localhost";
    private $dbname = "chating";
    private $conn;

    public function __construct() {
        $this->conn = new mysqli($this->server, $this->user, $this->pass, $this->dbname);

        if ($this->conn->connect_error) {
            echo json_encode([
                'status' => 'error',
                'message' => 'Connection failed: ' . $this->conn->connect_error
            ]);
            http_response_code(500);
            exit();
        }
    }

    public function getConnection() {
        if (!$this->conn) {
            return ['status' => 'error', 'message' => 'Database connection is not available'];
        }
        return $this->conn;
    }

    public function verifyOTP($email, $otp) {
        $query = "SELECT * FROM otp WHERE email = ? AND otp_code = ? AND expires_at > NOW()";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ss", $email, $otp);
        $stmt->execute();
        $result = $stmt->get_result();
    
        if ($result->num_rows > 0) {
            return json_encode(['status' => 'success', 'message' => 'OTP is valid']);
        } else {
            return json_encode(['status' => 'error', 'message' => 'OTP is invalid or expired']);
        }
    }
    
    public function addOTP($email, $otp) {
        // Hapus OTP lama jika ada, agar tidak ada duplikasi
        $deleteQuery = "DELETE FROM otp WHERE email = ?";
        $deleteStmt = $this->conn->prepare($deleteQuery);
        $deleteStmt->bind_param("s", $email);
        $deleteStmt->execute();
    
        // Masukkan OTP baru (created_at & expires_at otomatis)
        $query = "INSERT INTO otp (email, otp_code) VALUES (?, ?)";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ss", $email, $otp);
    
        if ($stmt->execute()) {
            return json_encode([
                'status' => 'success',
                'message' => 'OTP added successfully'
            ]);
        } else {
            return json_encode([
                'status' => 'error',
                'message' => 'Failed to insert OTP'
            ]);
        }
    }
    
}
?>
