<?php
require 'config.php';

// Pastikan request menggunakan metode POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $to = $_POST['to']; // Nomor tujuan dari request Android

    if (!$to) {
        echo json_encode(["status" => "error", "message" => "Nomor tujuan tidak boleh kosong"]);
        exit;
    }

    try {
        // Kirim panggilan dengan status callback
        $call = $twilio->calls->create(
            $to,  // Nomor tujuan
            $twilio_number, // Nomor Twilio
            [
                "url" => "http://demo.twilio.com/docs/voice.xml",
                "statusCallback" => "https://example.com/call_status.php", // Ganti dengan URL backend Anda
                "statusCallbackMethod" => "POST",
                "statusCallbackEvent" => ["initiated", "ringing", "answered", "completed"] // Status yang akan dikirim
            ]
        );

        echo json_encode(["status" => "success", "call_sid" => $call->sid]);
    } catch (Exception $e) {
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
}
?>
