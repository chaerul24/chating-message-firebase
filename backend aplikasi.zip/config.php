<?php
require 'vendor/autoload.php';
use Twilio\Rest\Client;

// Load environment variables
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

// Konfigurasi Twilio
$sid    = $_ENV['TWILIO_ACCOUNT_SID'];
$token  = $_ENV['TWILIO_AUTH_TOKEN'];
$secret = $_ENV['TWILIO_API_SECRET'];
$twilio_sms = $_ENV['TWILIO_SMS_SID'];
$sk = $_ENV['TWILIO_API_SK'];
$twilio = new Client($sid, $token);
$twilio_number = $_ENV['TWILIO_NUMBER'];

?>
