<?php
require __DIR__ . '/vendor/autoload.php';
require 'config.php';

use Twilio\Jwt\AccessToken;
use Twilio\Jwt\Grants\VideoGrant;

// Aktifkan error reporting untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Pastikan semua kredensial ada
if (empty($sid) || empty($sk) || empty($secret)) {
    $response = [
        'status' => 'error',
        'message' => 'Missing Twilio credentials'
    ];
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// Dapatkan identity dari parameter URL
$identity = isset($_GET['identity']) ? $_GET['identity'] . "_" . rand(1000, 9999) : 'guest_' . rand(1000, 9999);

try {
    // Buat token akses
    $token = new AccessToken(
        $sid,
        $sk,
        $secret,
        3600, // Token berlaku 1 jam
        $identity
    );

    // Beri izin akses ke Twilio Video
    $videoGrant = new VideoGrant();
    $token->addGrant($videoGrant);

    // Kirim token sebagai JSON
    $response = [
        'status' => 'ok',
        'identity' => $identity,
        'token' => $token->toJWT()
    ];
} catch (Exception $e) {
    // Tangani error jika terjadi kesalahan
    $response = [
        'status' => 'error',
        'message' => $e->getMessage()
    ];
}

// Set header dan kirim response JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
