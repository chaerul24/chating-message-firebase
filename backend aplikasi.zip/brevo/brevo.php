<?php
require __DIR__ . '/../vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class EmailSender {
    public function sendEmail($toEmail, $subject, $bodyContent) {
        $mail = new PHPMailer(true);
        
        try {
            // Server settings
            $mail->isSMTP();
            $mail->Host       = 'smtp-relay.brevo.com';  // Host SMTP (Brevo)
            $mail->SMTPAuth   = true;
            $mail->Username   = "87f234001@smtp-brevo.com";      // Ambil dari environment variable
            $mail->Password   = "password";      // Ambil dari environment variable
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = 587;
            
            // Pengirim dan penerima
            $mail->setFrom("emailkamu@gmail.com", getenv('MAIL_FROM_NAME'));
            $mail->addAddress($toEmail);
            
            // Konten email
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $bodyContent;

            $mail->send();

            return true;
        } catch (Exception $e) {
            error_log("Email gagal dikirim: " . $mail->ErrorInfo);
            return false;
        }
    }

    /**
     * Generates a random OTP (One-Time Password) of the given length (default to 6).
     * The OTP will contain a mix of uppercase and lowercase letters and numbers.
     * 
     * @param int $length The length of the OTP to generate (default to 6).
     * @return string The generated OTP.
     */
    function randomOtp($length = 6) {
        return substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'), 0, $length);
    }
}
