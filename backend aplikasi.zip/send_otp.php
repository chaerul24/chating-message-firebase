<?php
header('Content-Type: application/json');
require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/brevo/brevo.php';
require __DIR__ . '/db/config.php';

$emailSender = new EmailSender();
$db = new Database();

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET['email'])) {
        $email = $_GET['email'];
        $otpRandom = $emailSender->randomOtp(6);

        // Membuat email body
        $body = '<!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Chating OTP</title>
            </head>
            <body>
                <h1>Verifikasi Kode OTP</h1>
                <p>Kode OTP anda adalah: <strong style="font-size: 20px; background: grey; color: white;padding:5px;">' . $otpRandom . '</strong></p>
                <p>Gunakan kode OTP diatas untuk verifikasi akun anda.</p>
                <p>Terima kasih.</p>
            </body>
            </html>';
        $emailSender->sendEmail($email, 'Verifikasi OTP', $body);
        echo $db->addOTP($email, $otpRandom);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Email is required'], JSON_PRETTY_PRINT);
        exit;
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Method not allowed!'], JSON_PRETTY_PRINT);
    exit;
}
?>
